/**
 * Magic-byte file-type detection.
 *
 * Inspects the leading bytes of the uploaded content and returns a canonical
 * MIME type only when the signature matches a supported thesis-document type.
 * Returns null for anything unrecognised or unsupported (caller must reject).
 *
 * Supported: PDF, JPEG, PNG, DOCX.
 * A bare ZIP signature is NOT accepted as DOCX: OOXML word-processing files
 * must contain the `word/document.xml` part name in their local file headers.
 */

interface MagicRule {
  mime: string;
  bytes: number[];
}

const RULES: MagicRule[] = [
  // PDF: %PDF
  { mime: "application/pdf", bytes: [0x25, 0x50, 0x44, 0x46] },
  // JPEG: FF D8 FF
  { mime: "image/jpeg", bytes: [0xff, 0xd8, 0xff] },
  // PNG: 89 50 4E 47
  { mime: "image/png", bytes: [0x89, 0x50, 0x4e, 0x47] },
];

/** ZIP local file header signature: PK\x03\x04 */
const ZIP_SIGNATURE = [0x50, 0x4b, 0x03, 0x04];

/** Canonical allowed MIME types for thesis files. */
export const ALLOWED_MIME_TYPES = new Set([
  "application/pdf",
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
  "image/jpeg",
  "image/png",
]);

function startsWith(header: Uint8Array, bytes: number[]): boolean {
  if (header.length < bytes.length) return false;
  return bytes.every((b, i) => header[i] === b);
}

/**
 * Detects file type from magic bytes.
 * @param header Leading bytes of the file (pass at least the first 64 KB so
 *               ZIP part names can be inspected).
 * @returns Canonical allowed MIME type, or null when unsupported/unrecognised.
 */
export function detectMimeType(header: Uint8Array): string | null {
  for (const rule of RULES) {
    if (startsWith(header, rule.bytes)) return rule.mime;
  }

  if (startsWith(header, ZIP_SIGNATURE)) {
    // OOXML containers store entry names in plaintext inside local headers.
    // Only a word-processing document (word/document.xml) is accepted;
    // spreadsheets, presentations and arbitrary ZIP archives are rejected.
    const text = Buffer.from(header).toString("latin1");
    if (text.includes("word/document.xml")) {
      return "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
    }
    return null;
  }

  return null;
}
